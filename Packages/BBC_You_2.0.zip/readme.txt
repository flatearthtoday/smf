[center][url=http://smftricks.com][img]http://smftricks.com/Themes/SMFHispano/images/theme/logo.png[/img][/url][/center]
[hr]

[center][b][size=14pt]BBC You[/size][/b]
[size=8pt]Developed by [url=http://smftricks.com/index.php?action=profile;u=1]Diego Andr�s[/url][/center]

[hr]

[size=12pt][color=red]Introduction[/color][/size]
[size=8pt]BBC [you] tag adds a BBC tag that allows users to echo out the name of the user who is reading the topic.[/size]


[hr]

[size=12pt][color=red]License[/color][/size]
[code]This Source Code Form is subject to the terms of the Mozilla Public License, v. 1.1.
If a copy of the MPL was not distributed with this file,
You can obtain one at http://mozilla.org/MPL/

The contents of this package are subject to the Mozilla Public License Version
1.1 (the "License"); you may not use this package except in compliance with
the License. You may obtain a copy of the License at
http://www.mozilla.org/MPL/
 *
Software distributed under the License is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
for the specific language governing rights and limitations under the
License.[/code]