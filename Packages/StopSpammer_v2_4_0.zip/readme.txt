[b]MOD Stop Spammer v2.4.0
==================[/b]

[table]
[tr][td][b]Author:[/b][/td][td][url=https://www.simplemachines.org/community/index.php?action=profile;u=389][b]Matthias[/b][/td][/tr]
[tr][td][b]Past Releases:[/b][/td][td][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=148997][b]M-DVD[/b][/url] and [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=68708][b]snoopy_virtual[/b][/url][/td][/tr]
[tr][td][b]Version:[/b][/td][td]2.4.0[/td][/tr]

[tr][td][b]Release:[/b][/td][td]5th February 2021[/td][/tr]

[tr][td][b]Compatible With:[/b][/td][td]SMF 1.1.1 - 1.1.12
SMF 2.0.15 - 2.0.18[/td][/tr]

[tr][td][b]Languages:[/b][/td][td][img]http://www.simplemachines.org/site_images/lang/english.gif[/img] [img]http://www.simplemachines.org/site_images/lang/english_british.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish_latin.gif[/img] [img]http://www.simplemachines.org/site_images/lang/arabic.gif[/img] [img]http://www.simplemachines.org/site_images/lang/french.gif[/img]
[img]http://www.simplemachines.org/site_images/lang/bulgarian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/portuguese_pt.gif[/img] [img]http://www.simplemachines.org/site_images/lang/portuguese_brazilian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/dutch.gif[/img] [img]http://www.simplemachines.org/site_images/lang/indonesian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/italian.gif[/img]
[img]http://www.simplemachines.org/site_images/lang/danish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/turkish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/russian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/ukrainian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/chinese-simplified.gif[/img] [img]http://www.simplemachines.org/site_images/lang/chinese-traditional.gif[/img]
[img]http://www.simplemachines.org/site_images/lang/swedish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/german.gif[/img] [img]http://www.simplemachines.org/site_images/lang/polish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/croatian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/hungarian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/norwegian.gif[/img]
[img]http://www.simplemachines.org/site_images/lang/finnish.gif[/img] [/td][/tr]
[/table]

[url=http://www.simplemachines.org/community/index.php?topic=283309.msg1920848#msg1920848][color=green][b]Read FAQ[/b][/color][/url]

[b]Features:[/b]

If you don't know how this mod works you can [url=http://custom.simplemachines.org/mods/index.php?mod=1547]find more info here[/url] and inside the [url=http://www.simplemachines.org/community/index.php?topic=283309.0]official mod's support thread[/url].

Thanks to 'Stop Forum Spam' for your DB and APIs.

Thanks to [url=http://www.simplemachines.org/community/index.php?action=profile;u=139580][b]WhatsTheRent[/b][/url] and [url=http://www.simplemachines.org/community/index.php?action=profile;u=130133][b]KahneFan[/b][/url] for idea.
