[size=large][b]SMF 2.0.16[/b][/size]

SMF 2.0.16 is a significant update for the 2.0.x line.

Most notably, 2.0.16 enables forums comply with the [b]European Union's [url=https://ec.europa.eu/commission/priorities/justice-and-fundamental-rights/data-protection/2018-reform-eu-data-protection-rules_en]General Data Protection Regulation[/url][/b]. These changes include:
[list]
[li]A new [b]GDPR Compliance[/b] feature in Core Features. Enabling this Core Feature will automatically configure the settings on your forum to make it compliant with the GDPR.[/li]
[li]User profile data export.[/li]
[li]Unsubscribe links in email notifications, newsletters, etc., that don't require login.[/li]
[li]Letting new users choose during registration whether or not to receive newsletters.[/li]
[li]Automated tracking of revisions to the registration agreement, including requiring users to read and accept updates to the agreement in order to continue using the forum.[/li]
[li]Support for privacy policy in addition to the registration agreement: [list]
	[li]Versions of the privacy policy can be created for each installed language.[/li]
	[li]Registration requires acceptance of the privacy policy.[/li]
	[li]Automated tracking of revisions to the privacy policy, including requiring users to read and accept updates to the privacy policy in order to continue using the forum.[/li]
	[li]Links to the privacy policy and registration agreement are included in the footer of every page.[/li][/list]
[/list]

Other notable changes in 2.0.16 include:
[list]
[li]Fixes and improvements for the image proxy.[/li]
[li]Security improvements.[/li]
[li]Suppression of deprecation warnings when running PHP 7.2 or later.[/li]
[li]Restored support for PHP 5.3. (Do note, however, that the upcoming SMF 2.1 release really does require at least PHP 5.4.)[/li]
[li]Other bug fixes and improvements.[/li]
[/list]

[b]All users, including the admin, will need to log in again after this patch has been installed.[/b]
