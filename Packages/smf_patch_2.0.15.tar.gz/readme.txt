Changelog
=========
[list]
[li]A security issue reported by Daniel Le Gall, SCRT SA[/li]
[li]Various bug fixes with Proxy handler[/li]
[li]Login fixes for SSI and Maintenance Mode[/li]
[li]Various Search fixes[/li]
[li]Fixes email handling issue when using SendTopic[/li]
[li]Fixed SM statistics collection and added enrollment option to admin panel[/li]
[/list]

This release requires at least PHP 5.4 to function. Most hosts should have it or something newer. You can check which version of PHP that you are running by visiting the "Support and Credits" section of the Administration Center.

